let cursorLocation = 1;
const menuButtonLocations = [
    [1 , 2],
    [3, 4]
];
function initialize()
{
    audio = new Audio("bgmusic.mp3");
    currentButton = attackButton;
    currentButton.style.color = "white";

    document.querySelector("#winnerText").innerHTML = "";

    playerStrength = 6;
    playerCunning = 6;
    playerSpeed = 6;
    playerFatigue = 30;

    enemyStrength = 6;
    enemyCunning = 6;
    enemySpeed = 6;
    enemyFatigue = 30;

    playerDefending = false;
    enemyDefending = false;

    playerAttacking = false;
    playerDefending = false;

    playerPerformedFinisher = false;
    enemyPerformedFinisher = false;

    playerHasItem = true;

    gameRunning = true;
    setStats();
    
}
function setStats()
{
    let values = [0, 0, 0 ,0]; // 0 means that value is increasing by a modifier, 1 means it is decreasing
    //index of 0 is Strength, index of 1 is Cunning, 
    //index of 2 is Speed, index of 3 is Fatigue
    let hasTwoPairs = false;
    while (!hasTwoPairs)
    {
        let numOfZeros = 0;
        let numOfOnes = 0;
        for (let i = 0; i < values.length; i++)
        {
            values[i] = getRandomInteger(0, 1);
        }
        for (let i = 0; i < values.length; i++)
        {
            if (values[i] === 0)
            {
                numOfZeros++;
            }else{
                numOfOnes++;
            }
        }
        if (numOfZeros === 2 && numOfOnes === 2){hasTwoPairs = true}else{values = [0, 0, 0, 0];}
    }
    let modifier = getRandomInteger(0, 1);
    if (values[0] === 1){modifier *= -1;}
    playerStrength += modifier;
    modifier = getRandomInteger(0, 1);
    if (values[1] === 1){modifier *= -1;}
    playerCunning += modifier;
    modifier = getRandomInteger(0, 1);
    if (values[2] === 1){modifier *= -1;}
    playerSpeed += modifier;
    modifier = getRandomInteger(0, 6);
    if (values[3] === 1){modifier *= -1;}
    playerFatigue += modifier;

    //re-declare the values array for the computer's fighter
    values = [0, 0, 0, 0];
    hasTwoPairs = false;
    while (!hasTwoPairs)
    {
        let numOfZeros = 0;
        let numOfOnes = 0;
        for (let i = 0; i < values.length; i++)
        {
            values[i] = getRandomInteger(0, 1);
        }
        for (let i = 0; i < values.length; i++)
        {
            if (values[i] === 0)
            {
                numOfZeros++;
            }else{
                numOfOnes++;
            }
        }
        if (numOfZeros === 2 && numOfOnes === 2){hasTwoPairs = true}else{values = [0, 0, 0, 0];}
    }
    modifier = getRandomInteger(0, 1);
    if (values[0] === 1){modifier *= -1;}
    enemyStrength += modifier;
    modifier = getRandomInteger(0, 1);
    if (values[1] === 1){modifier *= -1;}
    enemyCunning += modifier;
    modifier = getRandomInteger(0, 1);
    if (values[2] === 1){modifier *= -1;}
    enemySpeed += modifier;
    modifier = getRandomInteger(0, 6);
    if (values[3] === 1){modifier *= -1;}
    enemyFatigue += modifier;


    pStrength.innerHTML = playerStrength;
    pSpeed.innerHTML = playerSpeed;
    pCunning.innerHTML = playerCunning;
    pFatigue.innerHTML = playerFatigue;
    php.innerHTML = playerFatigue;

    eStrength.innerHTML = enemyStrength;
    eSpeed.innerHTML = enemySpeed;
    eCunning.innerHTML = enemyCunning;
    eFatigue.innerHTML = enemyFatigue;
    ehp.innerHTML = enemyFatigue;


    console.log("Player Stats: Strength = " + playerStrength + " Speed = " + playerSpeed + " Cunning = " + playerCunning + " Fatigue= " + playerFatigue);
    console.log("Enemy Stats: Strength = " + enemyStrength + " Speed = " + enemySpeed + " Cunning = " + enemyCunning + " Fatigue= " + enemyFatigue);
}
function getRandomInteger(lower, upper)
{
    var multiplier = upper - (lower - 1);
    var rnd = parseInt(Math.random() * multiplier) + lower;
    return rnd;
}
function arrowKeyPressed(direction)
{
    let pastCursorLocation = cursorLocation;
    if (direction === "ArrowUp")
    {
        if (cursorLocation === 3 || cursorLocation === 4)
        {
            cursorLocation -= 2;
        }
    }
    if (direction === "ArrowDown")
    {
        if (cursorLocation === 1 || cursorLocation === 2)
        {
            cursorLocation += 2;
        }
    }
    if (direction === "ArrowLeft")
    {
        if (cursorLocation === 2 || cursorLocation === 4)
        {
            cursorLocation -= 1;
        }
    }
    if (direction === "ArrowRight")
    {
        if (cursorLocation === 1 || cursorLocation === 3)
        {
            cursorLocation += 1;
        }
    }
    if (cursorLocation !== pastCursorLocation)
    {
        updateCursor();
    }
}
function updateCursor()
{
    currentButton.style.color = "rgb(114, 114, 114)";
    if (cursorLocation === 1)
    {
        currentButton = attackButton;
    }else if(cursorLocation === 2)
    {
        currentButton = finishingMoveButton;
    }else if (cursorLocation === 3)
    {
        currentButton = guardButton;
    }else if (cursorLocation === 4)
    {
        currentButton = itemButton;
    }
    currentButton.style.color = "white";
}
function playerAttack()
{
    playerAttacking = true;
    let playerAttackValue = Math.round((playerStrength + playerSpeed + playerCunning)/(getRandomInteger(1, 3)));
    let enemyDefenseValue = 0;
    if (enemyDefending === true)
    {
        enemyDefenseValue += enemySpeed + enemyCunning;
    }else{
        enemyDefenseValue += enemySpeed + getRandomInteger(1, 6);
    }
    if (playerAttackValue < enemyDefenseValue)
    {
        playerAttackValue = 0;
        enemyDefenseValue = 0;
    }
    realPlayerAttackValue = playerAttackValue - enemyDefenseValue;
    enemyFatigue -= realPlayerAttackValue;

    let newRow = playerListedMoves.insertRow();
    let newCell = newRow.insertCell();
    newCell.innerHTML = "Joker used ATTACK!";

    newCell = newRow.insertCell();
    newCell.innerHTML = realPlayerAttackValue + " damage...";

    newRow = enemyListedMoves.insertRow();
    newCell = newRow.insertCell();
    newCell.innerHTML = "Enemy took damage";
    if (enemyDefending)
    {
        newCell.innerHTML += " while blocking"
    }
    newCell = newRow.insertCell();
    newCell.innerHTML = realPlayerAttackValue + " damage...";
}
function playerFinishingMove()
{
    if ((playerFatigue >= 2*enemyFatigue) || enemyFatigue < 0)
    {
        let success = false;
        playerPerformedFinisher = true;
        let playerAttackValue = Math.round((playerStrength + playerSpeed)/(getRandomInteger(1, 3)));
        let enemyDefenseValue = 0;
        if (enemyDefending === true)
        {
            enemyDefenseValue += enemySpeed + enemyCunning;
        }else{
            enemyDefenseValue += enemySpeed + getRandomInteger(1, 6);
        }
        if (playerAttackValue < enemyDefenseValue)
        {
            playerAttackValue = 0;
            enemyDefenseValue = 0;
        }else{
            success = true;
        }
        let newRow1 = playerListedMoves.insertRow();
        let newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Joker used FINISHING MOVE!";
        let newRow2 = enemyListedMoves.insertRow();
        let newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "Enemy was hit with a finisher!";
        if (success)
        {
            newCell1 = newRow1.insertCell();
            newCell1.innerHTML = "SUCCESS! Joker wins!";
            newCell2 = newRow2.insertCell();
            newCell2.innerHTML = "Enemy is eliminated!";
            finishGame("Joker");
        }else{
            newCell1 = newRow1.insertCell();
            newCell1.innerHTML = "Failure! Game continues!";
            newCell2 = newRow2.insertCell();
            newCell2.innerHTML = "Enemy survives...";
        }

    }else{
        let newRow1 = playerListedMoves.insertRow();
        let newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Joker attempted FINISHING MOVE!";
        newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Can't use that yet! Wasted turn!";

        let newRow2 = enemyListedMoves.insertRow();
        let newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "Enemy was hit with a finisher!";
        newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "It doesn't work...";
    }
}
function finishGame(winner)
{
    winnerText.innerHTML =  ` ${winner} wins!`;
    gameRunning = false;
}
function playerDefend()
{
    playerDefending = true;
    if (!enemyAttacking)
    {
        let recoveryPoints = getRandomInteger(1, 6);
        let newRow = playerListedMoves.insertRow();
        let newCell = newRow.insertCell();
        newCell.innerHTML = "Joker used Guard!";

        newCell = newRow.insertCell();
        newCell.innerHTML = "Healed " + recoveryPoints + "...";

        playerFatigue += recoveryPoints;
    }
}
function playerItem()
{
    if (playerHasItem)
    {
        playerFatigue += 8;
        let newRow1 = playerListedMoves.insertRow();
        let newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Joker used an item!";
        newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Recovered 8 fatigue!";

        let newRow2 = enemyListedMoves.insertRow();
        let newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "Enemy is waiting";
        newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "...";
        playerHasItem = false;
    }else{
        let newRow1 = playerListedMoves.insertRow();
        let newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Joker has no more items!";
        newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Wasted turn";

        let newRow2 = enemyListedMoves.insertRow();
        let newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "Enemy is waiting";
        newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "...";
    }
}
function enemyAttack()
{
    enemyAttacking = true;
    let enemyAttackValue = Math.round((enemyStrength + enemySpeed + enemyCunning)/(getRandomInteger(1, 3)));
    let playerDefenseValue = 0;
    if (playerDefending === true)
    {
        playerDefenseValue += playerSpeed + playerCunning;
    }else{
        playerDefenseValue += playerSpeed + getRandomInteger(1, 6);
    }
    if (enemyAttackValue < playerDefenseValue){
        enemyAttackValue = 0;
        playerDefenseValue = 0;
    }
    realEnemyAttackValue = enemyAttackValue - playerDefenseValue;
    playerFatigue -= realEnemyAttackValue;

    let newRow = enemyListedMoves.insertRow();
    let newCell = newRow.insertCell();
    newCell.innerHTML = "Enemy used ATTACK!";

    newCell = newRow.insertCell();
    newCell.innerHTML = realEnemyAttackValue + " damage...";

    newRow = playerListedMoves.insertRow();
    newCell = newRow.insertCell();
    newCell.innerHTML = "Joker took damage";
    if (playerDefending)
    {
        newCell.innerHTML += " while blocking"
    }
    newCell = newRow.insertCell();
    newCell.innerHTML = realEnemyAttackValue + " damage...";
}
function enemyDefend()
{
    enemyDefending = true;
    if (!playerAttacking)
    {
        let recoveryPoints = getRandomInteger(1, 6);
        let newRow = enemyListedMoves.insertRow();
        let newCell = newRow.insertCell();
        newCell.innerHTML = "Enemy used Guard!";

        newCell = newRow.insertCell();
        newCell.innerHTML = "Healed " + recoveryPoints + "...";

        enemyFatigue += recoveryPoints;
    }
}
function enemyFinishingMove()
{
    if ((enemyFatigue >= 2*playerFatigue) || playerFatigue < 0)
    {
        let success = false;
        enemyPerformedFinisher = true;
        let enemyAttackValue = Math.round((enemyStrength + enemySpeed)/(getRandomInteger(1, 3)));
        let playerDefenseValue = 0;
        if (playerDefending === true)
        {
            playerDefenseValue += playerSpeed + playerCunning;
        }else{
            playerDefenseValue += playerSpeed + getRandomInteger(1, 6);
        }
        if (enemyAttackValue < playerDefenseValue)
        {
            enemyAttackValue = 0;
            playerDefenseValue = 0;
        }else{
            success = true;
        }
        let newRow1 = enemyListedMoves.insertRow();
        let newCell1 = newRow1.insertCell();
        newCell1.innerHTML = "Enemy used FINISHING MOVE!";
        let newRow2 = playerListedMoves.insertRow();
        let newCell2 = newRow2.insertCell();
        newCell2.innerHTML = "Joker was hit with a finisher!";
        if (success)
        {
            newCell1 = newRow1.insertCell();
            newCell1.innerHTML = "SUCCESS! Enemy wins!";
            newCell2 = newRow2.insertCell();
            newCell2.innerHTML = "Joker is eliminated!";
            finishGame("Enemy");
        }else{
            newCell1 = newRow1.insertCell();
            newCell1.innerHTML = "Failure! Game continues!";
            newCell2 = newRow2.insertCell();
            newCell2.innerHTML = "Joker survives...";
        }
    }
}
function updateFatigue()
{
    pFatigue.innerHTML = playerFatigue;
    eFatigue.innerHTML = enemyFatigue;

    php.innerHTML = playerFatigue;
    ehp.innerHTML = enemyFatigue;
}
document.addEventListener('keydown', (event) => {
    var name = event.key;
    if (name === "ArrowUp" || name === "ArrowDown" || name === "ArrowLeft" || name === "ArrowRight")
    {
        console.log(name);
        arrowKeyPressed(name);
    }
    if(name === "M" || name === "m")
    {
        audio.play();
    }
    if (name === "Enter" && gameRunning === true)
    {
        console.log(currentButton.id + "entered");
        enemyChoice = getRandomInteger(1,2);
        switch(cursorLocation)
        {
            case 1:
                enemyDefending = (enemyChoice === 2) ? true : false;
                playerAttack();
                playerAttacking = false;
                enemyDefending = false;
            break;
            case 2:
                if (enemyChoice === 2)
                {
                    enemyDefending = true;
                }
                playerFinishingMove();
                enemyDefending = false;
                playerAttacking = false;
            break;
            case 3:
                if (enemyChoice === 1)
                {
                    enemyAttacking = true;
                }
                playerDefend();
                playerDefending = false;
                enemyAttacking = false;
            break;
            case 4: 
                playerItem();
            break;
            default:
                console.log("error"); 
        }
        if (enemyFatigue >= 2*playerFatigue || playerFatigue < 0)
        {
            if (cursorLocation === 3)
            {
                playerDefending = true;
            }
            enemyFinishingMove();
            playerDefending = false;
            enemyAttacking = false;
        }else{
            switch(enemyChoice)
            {
                case 1:
                    if (cursorLocation === 3)
                    {
                        playerDefending = true;
                    }
                    enemyAttack();
                    console.log("ran ea")
                    playerDefending = false;
                    enemyAttacking = false;
                break;
                case 2:
                    if (cursorLocation === 1)
                    {
                        playerAttacking = true;
                    }
                    enemyDefend();
                    console.log("ran ed")
                    playerAttacking = false;
                    enemyDefending = false;
                break;
                default:
                    console.log("error"); 
            }
        }
        updateFatigue();
    }
  }, false);